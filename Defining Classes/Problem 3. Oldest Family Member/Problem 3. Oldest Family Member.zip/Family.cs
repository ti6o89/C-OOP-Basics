﻿
using System.Collections.Generic;
using System.Linq;

public class Family
{
    public Family()
    {
        this.members = new List<Person>();
    }
    
    private List<Person> members;

    public void AddMember(Person member)
    {
        this.members.Add(member);
    }

    public Person GetOldestMember()
    {
        return this.members
            .OrderByDescending(p => p.Age)
            .FirstOrDefault();
    }
}
