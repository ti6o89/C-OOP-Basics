﻿public class Cat
{
    private string name;
    private string breed;

    public string Name
    {
        get
        {
            return this.name;
        }
        set
        {
            this.name = value;
        }
    }

    public string Breed
    {
        get
        {
            return this.breed;
        }
        set
        {
            this.breed = value;
        }
    }
}