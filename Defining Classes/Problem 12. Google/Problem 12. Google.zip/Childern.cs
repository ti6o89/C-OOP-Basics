﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class Childern
{
    private string childrenName;
    private string childrenBirthday;

    public Childern(string childrenName, string childrenBirthday)
    {
        this.childrenName = childrenName;
        this.childrenBirthday = childrenBirthday;
    }

    public string Name
    {
        get { return this.childrenName; }
    }

    public string Birthday
    {
        get { return this.childrenBirthday; }
    }
}

