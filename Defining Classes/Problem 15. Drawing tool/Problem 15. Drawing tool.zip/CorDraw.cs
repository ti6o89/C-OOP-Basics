﻿public class CorDraw
{
    private string figure;

    public string Figure
    {
        get
        {
            return this.figure;
        }
        set
        {
            this.figure = value;
        }
    }
}